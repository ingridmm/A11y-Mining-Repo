<p>As mention in the comments, you are checking the length of a string wich is null. So therefore it has no length. Instead first check for null or empty then you can continue.</p>
<pre><code>protected async Task CheckAnswer()
{
    if (!string.IsNullOrEmpty(UserAnswer))
    {
        if (UserAnswer.ToLower() == CorrectAnswer.ToLower())
        {
            value=" Correct" 
        }
        else
        {
             value = " Incorrect" ;
        }
    }
}
</code></pre>
